# Storycreep authoring export

This archive holds the authoring data of the project "The Lighthouse Keeper", in version 1 of the format storycreep.authoring, which
`authoring.json` describes and `schema/authoring/v1/archive.schema.json` of the Storycreep repository
defines. It was made at 2026-11-24T05:37:31Z.

## Personal data

This is a content-only export. It holds no comments, play states, or annotations, and it does not
name the people who worked on the project. The story's own text may still mention real people.

## What it holds

The content is the project's draft as it was when the archive was made, under `draft/`, without
what is in the project's trash.

- `draft/project.json`: project, 1 item(s)
- `draft/folders.json`: folders, 2 item(s)
- `draft/boards.json`: boards, 3 item(s)
- `draft/variables.json`: variables, 6 item(s)
- `draft/component_types.json`: component_types, 5 item(s)
- `draft/components.json`: components, 4 item(s)
- `draft/nodes.json`: nodes, 40 item(s)
- `draft/branch_outputs.json`: branch_outputs, 8 item(s)
- `draft/connections.json`: connections, 53 item(s)
- `draft/expressions.json`: expressions, 21 item(s)
- `draft/validation_mutes.json`: validation_mutes, 0 item(s)
- `releases/index.json`: releases, 0 item(s)

Each release of the history has its files under `releases/<its ID>/`.

This archive holds no assets: the images that its content refers to are not in it.
